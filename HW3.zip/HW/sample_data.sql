USE `book_industry`;

INSERT INTO `Authors` VALUES(1,'Mr. X');
INSERT INTO `Authors` VALUES(2,'Mr. Y');
INSERT INTO `Authors` VALUES(3,'Mr. Z');
INSERT INTO `Authors` VALUES(4,'Mr. W');


INSERT INTO `Publishers` VALUES(1,'Pub. X');
INSERT INTO `Publishers` VALUES(2,'Pub. Y');
INSERT INTO `Publishers` VALUES(3,'Pub. Z');
INSERT INTO `Publishers` VALUES(4,'Pub. W');

INSERT INTO `Editors` VALUES(1,'Mr. Edit. X');
INSERT INTO `Editors` VALUES(2,'Mr. Edit. Y');
INSERT INTO `Editors` VALUES(3,'Mr. Edit. Z');
INSERT INTO `Editors` VALUES(4,'Mr. Edit. W');


INSERT INTO `Books` VALUES(1,'Book 1',1,2,1,'Drama',12);
INSERT INTO `Books` VALUES(2,'Book 2',2,2,2,'Action',5);
INSERT INTO `Books` VALUES(3,'Book 3',3,3,1,'Action',4);
INSERT INTO `Books` VALUES(4,'Book 4',4,3,3,'Romance',3);
INSERT INTO `Books` VALUES(5,'Book 5',4,1,1,'Action',2);


INSERT INTO `Orders` VALUES(11,1);
INSERT INTO `Orders` VALUES(22,2);
INSERT INTO `Orders` VALUES(33,2);
INSERT INTO `Orders` VALUES(44,4);


INSERT INTO `Customer` VALUES(1,'Mr. Cust. X',11);
INSERT INTO `Customer` VALUES(2,'Mr. Cust. Y',22);
INSERT INTO `Customer` VALUES(3,'Mr. Cust. Z',33);
INSERT INTO `Customer` VALUES(4,'Mr. Cust. W',44);




